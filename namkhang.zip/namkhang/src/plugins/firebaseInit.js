// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyAKar8bxtUpjhZpAuzS6Z5Xe4AyBnUxUAQ",
  authDomain: "fir-3492.firebaseapp.com",
  projectId: "fir-3492",
  storageBucket: "fir-3492.appspot.com",
  messagingSenderId: "1049555638903",
  appId: "1:1049555638903:web:f42d1f618ddb613a39c472",
  measurementId: "G-Z6JNZLC670",
});

const db = getFirestore(firebaseApp);
export default db;
